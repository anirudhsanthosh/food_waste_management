declare module JWT{

    interface generate{
        email:string,
        uuid:string,
        name:string | null,
    }
}