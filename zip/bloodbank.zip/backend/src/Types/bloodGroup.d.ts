interface bloodGroupCreatePayload {
    name: string
    group: string
    comments: string
    stock?: number
    variation: string
}