// @ts-nocheck
import Joi from 'joi';


export const AddressWhereUniqueInputSchemaObject = {
    id: Joi.string()
}