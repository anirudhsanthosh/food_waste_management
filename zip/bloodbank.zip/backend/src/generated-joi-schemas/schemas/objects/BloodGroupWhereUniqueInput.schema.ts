// @ts-nocheck
import Joi from 'joi';


export const BloodGroupWhereUniqueInputSchemaObject = {
    id: Joi.string()
}