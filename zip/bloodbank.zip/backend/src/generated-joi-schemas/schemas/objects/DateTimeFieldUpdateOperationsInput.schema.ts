// @ts-nocheck
import Joi from 'joi';


export const DateTimeFieldUpdateOperationsInputSchemaObject = {
    set: Joi.date()
}