// @ts-nocheck
import Joi from 'joi';


export const DonationWhereUniqueInputSchemaObject = {
    id: Joi.string()
}