// @ts-nocheck
import Joi from 'joi';
import { SortOrderSchema } from '../enums/SortOrder.schema'

export const HealthReportOrderByRelationAggregateInputSchemaObject = {
    _count: SortOrderSchema
}