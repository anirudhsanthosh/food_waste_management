// @ts-nocheck
import Joi from 'joi';


export const HealthReportWhereUniqueInputSchemaObject = {
    id: Joi.string()
}