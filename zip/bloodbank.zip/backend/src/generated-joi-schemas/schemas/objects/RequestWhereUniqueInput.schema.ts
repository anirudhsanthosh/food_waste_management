// @ts-nocheck
import Joi from 'joi';


export const RequestWhereUniqueInputSchemaObject = {
    id: Joi.string()
}