// @ts-nocheck
import Joi from 'joi';
import { SortOrderSchema } from '../enums/SortOrder.schema'

export const UserAvgOrderByAggregateInputSchemaObject = {
    id: SortOrderSchema,
  age: SortOrderSchema
}