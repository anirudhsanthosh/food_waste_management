// @ts-nocheck
import Joi from 'joi';
import { SortOrderSchema } from '../enums/SortOrder.schema'

export const UserSumOrderByAggregateInputSchemaObject = {
    id: SortOrderSchema,
  age: SortOrderSchema
}