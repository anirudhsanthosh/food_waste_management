// @ts-nocheck
import Joi from 'joi';


export const UserWhereUniqueInputSchemaObject = {
    id: Joi.number(),
  uuid: Joi.string(),
  email: Joi.string()
}