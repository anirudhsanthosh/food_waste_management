export class Configurations{
    
    public static baseUrl = "http://localhost:5000";

    public static LOGIN_STATUS = 'svdasvavjhafjhvasjvjasd';
} 