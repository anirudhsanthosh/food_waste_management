-- AlterTable
ALTER TABLE "PickupRequest" ADD COLUMN "date" DATETIME;
ALTER TABLE "PickupRequest" ADD COLUMN "phone" TEXT;
ALTER TABLE "PickupRequest" ADD COLUMN "place" TEXT;
