declare module PickupRequest{
    interface createPayload {
        address : string,
        quantity : number,
        date:string,
        phone:string,
        place:string
    }
}